import NoteSearch
print('hello world')