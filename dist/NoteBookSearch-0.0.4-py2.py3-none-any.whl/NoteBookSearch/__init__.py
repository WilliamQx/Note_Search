# -*- coding: utf-8 -*-
# @Time    : 27/09/2022 6:10 PM
# @Author  : William
# @FileName: __init__.py.py
# @Software: PyCharm
from NoteBookSearch.NoteBookSearch import test
from NoteBookSearch.DataManager import DataManager
from NoteBookSearch.SEARCH_ENGINE import Search_engine

'''
This is to provide convenience to the users,  this will allow
them to import directly from NoteBookSearch,
"from NoteBookSearch import DataManager", now they don't need to have the .DataManager
as above. 
'''